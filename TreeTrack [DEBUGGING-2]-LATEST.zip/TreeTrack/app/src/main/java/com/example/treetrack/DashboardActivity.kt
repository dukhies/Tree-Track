package com.example.treetrack

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.firebase.auth.FirebaseAuth

class DashboardActivity : AppCompatActivity() {

    private lateinit var btnTrackTrees: Button
    private lateinit var btnMyTrees: Button
    private lateinit var btnHealthMonitor: Button
    private lateinit var btnReports: Button
    private lateinit var fabAddTree: FloatingActionButton
    private lateinit var btnSettings: ImageButton
    private lateinit var btnLogout: Button

    private val LOCATION_PERMISSION_REQUEST = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        // Initialize buttons
        btnTrackTrees = findViewById(R.id.btnTrackTrees)
        btnMyTrees = findViewById(R.id.btnMyTrees)
        btnHealthMonitor = findViewById(R.id.btnHealthMonitor)
        btnReports = findViewById(R.id.btnReports)
        fabAddTree = findViewById(R.id.fabAddTree)
        btnSettings = findViewById(R.id.btnSettings)
        btnLogout = findViewById(R.id.btnLogout)

        // Handle Track Trees button with location permission
        btnTrackTrees.setOnClickListener {
            val locationPermission = Manifest.permission.ACCESS_FINE_LOCATION
            if (ContextCompat.checkSelfPermission(this, locationPermission) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(locationPermission), LOCATION_PERMISSION_REQUEST)
            } else {
                startActivity(Intent(this, TrackTreesActivity::class.java))
            }
        }

        btnMyTrees.setOnClickListener {
            val intent = Intent(this, MyTreesActivity::class.java)
            startActivity(intent)
        }

        btnHealthMonitor.setOnClickListener {
            val intent = Intent(this, HealthMonitorActivity::class.java)
            startActivity(intent)
        }

        btnReports.setOnClickListener {
            val intent = Intent(this, ReportsActivity::class.java)
            startActivity(intent)
        }

        btnSettings.setOnClickListener {
            Toast.makeText(this, "Settings functionality coming soon!", Toast.LENGTH_SHORT).show()
        }

        btnLogout.setOnClickListener {
            FirebaseAuth.getInstance().signOut()
            TreeStorage.clearTrees()
            val intent = Intent(this, LoginActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == LOCATION_PERMISSION_REQUEST && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startActivity(Intent(this, TrackTreesActivity::class.java))
        } else {
            Toast.makeText(this, "Location permission is required to track trees.", Toast.LENGTH_SHORT).show()
        }
    }
}