package com.example.treetrack

import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import com.itextpdf.kernel.pdf.PdfDocument
import com.itextpdf.kernel.pdf.PdfWriter
import com.itextpdf.layout.Document
import com.itextpdf.layout.element.Paragraph
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

class ReportsActivity : AppCompatActivity() {

    private lateinit var btnExportPdf: Button
    private lateinit var dbRef: DatabaseReference
    private val treeList = mutableListOf<TreeData>()
    private val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reports)

        btnExportPdf = findViewById(R.id.btnExportPdf)
        btnExportPdf.setOnClickListener { fetchTreesAndGeneratePDF() }

        val currentUserId = FirebaseAuth.getInstance().currentUser?.uid
        if (currentUserId != null) {
            dbRef = FirebaseDatabase.getInstance().getReference("trees").child(currentUserId)
        } else {
            Toast.makeText(this, "User not logged in.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun fetchTreesAndGeneratePDF() {
        treeList.clear()

        dbRef.get().addOnSuccessListener { snapshot ->
            for (treeSnap in snapshot.children) {
                val tree = treeSnap.getValue(TreeData::class.java)
                tree?.let { treeList.add(it) }
            }
            generatePDF(treeList)
        }.addOnFailureListener {
            Toast.makeText(this, "Failed to fetch trees: ${it.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun generatePDF(trees: List<TreeData>) {
        try {
            val folder = File(getExternalFilesDir(null), "TreeReports")
            if (!folder.exists()) folder.mkdirs()

            val fileName = "Tree_Report_${System.currentTimeMillis()}.pdf"
            val pdfFile = File(folder, fileName)
            val writer = PdfWriter(FileOutputStream(pdfFile))
            val pdfDoc = PdfDocument(writer)
            val document = Document(pdfDoc)

            document.add(Paragraph("🌳 TreeTrack Report"))
            document.add(Paragraph("Generated: ${dateFormat.format(Date())}"))
            document.add(Paragraph("\n"))

            if (trees.isEmpty()) {
                document.add(Paragraph("No trees found."))
            } else {
                for (tree in trees) {
                    val daysOld = ((System.currentTimeMillis() - tree.datePlanted) / (1000 * 60 * 60 * 24)).toInt()
                    val healthStatus = when {
                        tree.health >= 80 -> "Excellent"
                        tree.health >= 60 -> "Good"
                        tree.health >= 40 -> "Moderate"
                        tree.health >= 20 -> "Poor"
                        else -> "Critical"
                    }

                    document.add(Paragraph("Name: ${tree.name}"))
                    document.add(Paragraph("Planted On: ${dateFormat.format(Date(tree.datePlanted))}"))
                    document.add(Paragraph("Age: $daysOld days"))
                    document.add(Paragraph("Health: $healthStatus (${tree.health}%)"))
                    document.add(Paragraph("Description: ${tree.description}"))
                    document.add(Paragraph("----------------------------\n"))
                }
            }

            document.close()
            Toast.makeText(this, "PDF saved to: ${pdfFile.absolutePath}", Toast.LENGTH_LONG).show()

        } catch (e: Exception) {
            Toast.makeText(this, "Error generating PDF: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
