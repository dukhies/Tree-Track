package com.example.treetrack

import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import java.text.SimpleDateFormat
import java.util.*

class HealthMonitorActivity : AppCompatActivity() {

    private lateinit var seekBarHealth: SeekBar
    private lateinit var tvHealthValue: TextView
    private lateinit var tvHealthStatus: TextView
    private lateinit var btnHealthCamera: Button
    private lateinit var btnHealthGallery: Button
    private lateinit var ivHealthThumbnail: ImageView
    private lateinit var tvLastCheckDate: TextView
    private lateinit var tvUploadTime: TextView
    private lateinit var btnUpdateHealth: Button
    private lateinit var lvTreeList: ListView
    private lateinit var healthMonitorContainer: LinearLayout
    private lateinit var tvSelectTree: TextView
    private lateinit var tvHeader: TextView

    private val dbRef by lazy { FirebaseDatabase.getInstance().getReference("trees") }
    private val auth by lazy { FirebaseAuth.getInstance() }
    private val uid by lazy { auth.currentUser?.uid.orEmpty() }

    private val treeList = mutableListOf<TreeData>()
    private var selectedTree: TreeData? = null
    private var photoUri: Uri? = null
    private val dateFormat = SimpleDateFormat("MM/dd/yyyy HH:mm", Locale.getDefault())

    private val galleryLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let {
            photoUri = it
            ivHealthThumbnail.setImageURI(it)
            updateUploadTime()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_health_monitor)

        lvTreeList = findViewById(R.id.lvTreeList)
        healthMonitorContainer = findViewById(R.id.healthMonitorContainer)
        tvSelectTree = findViewById(R.id.tvSelectTree)

        loadUserTrees()
    }

    private fun loadUserTrees() {
        dbRef.child(uid).addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                treeList.clear()
                for (treeSnap in snapshot.children) {
                    val tree = treeSnap.getValue(TreeData::class.java)
                    tree?.let {
                        it.id = treeSnap.key ?: ""
                        treeList.add(it)
                    }
                }
                showTreeSelection()
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@HealthMonitorActivity, "Failed to load trees", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun showTreeSelection() {
        lvTreeList.visibility = View.VISIBLE
        tvSelectTree.visibility = View.VISIBLE
        healthMonitorContainer.visibility = View.GONE

        val treeNames = treeList.map { it.name }
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, treeNames)
        lvTreeList.adapter = adapter

        lvTreeList.setOnItemClickListener { _, _, position, _ ->
            selectedTree = treeList[position]
            showHealthMonitorForTree(selectedTree!!)
        }
    }

    private fun showHealthMonitorForTree(tree: TreeData) {
        lvTreeList.visibility = View.GONE
        tvSelectTree.visibility = View.GONE
        healthMonitorContainer.visibility = View.VISIBLE

        initializeViews()
        setupHealthSlider()
        setupClickListeners()
        updateLastCheckDate()

        tvHeader.text = "Tree Health Monitor: ${tree.name}"
        seekBarHealth.progress = tree.health
        tvHealthValue.text = "${tree.health}%"
        updateHealthStatus(tree.health)
    }

    private fun initializeViews() {
        seekBarHealth = findViewById(R.id.seekBarHealth)
        tvHealthValue = findViewById(R.id.tvHealthValue)
        tvHealthStatus = findViewById(R.id.tvHealthStatus)
        btnHealthCamera = findViewById(R.id.btnHealthCamera)
        btnHealthGallery = findViewById(R.id.btnHealthGallery)
        ivHealthThumbnail = findViewById(R.id.ivHealthThumbnail)
        tvLastCheckDate = findViewById(R.id.tvLastCheckDate)
        tvUploadTime = findViewById(R.id.tvUploadTime)
        btnUpdateHealth = findViewById(R.id.btnUpdateHealth)
        tvHeader = findViewById(R.id.tvHealthHeader)
    }

    private fun setupHealthSlider() {
        seekBarHealth.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                tvHealthValue.text = "$progress%"
                updateHealthStatus(progress)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
    }

    private fun setupClickListeners() {
        btnHealthCamera.setOnClickListener { openCamera() }
        btnHealthGallery.setOnClickListener { openGallery() }
        btnUpdateHealth.setOnClickListener { updateHealthStatusFirebase() }
    }

    private fun updateHealthStatus(healthValue: Int) {
        val status = when {
            healthValue >= 80 -> "Excellent Health"
            healthValue >= 60 -> "Good Health"
            healthValue >= 40 -> "Moderate Health"
            healthValue >= 20 -> "Poor Health"
            else -> "Critical Health"
        }

        val color = when {
            healthValue >= 80 -> android.graphics.Color.GREEN
            healthValue >= 60 -> android.graphics.Color.rgb(0, 150, 0)
            healthValue >= 40 -> android.graphics.Color.YELLOW
            healthValue >= 20 -> android.graphics.Color.rgb(255, 165, 0)
            else -> android.graphics.Color.RED
        }

        tvHealthStatus.text = status
        tvHealthStatus.setTextColor(color)
    }

    private fun updateLastCheckDate() {
        val currentDate = dateFormat.format(Date())
        tvLastCheckDate.text = "Last Check: $currentDate"
    }

    private fun updateUploadTime() {
        val currentTime = dateFormat.format(Date())
        tvUploadTime.text = "Upload Time: $currentTime"
    }

    private fun openCamera() {
        Toast.makeText(this, "📸 Camera feature not yet implemented.", Toast.LENGTH_SHORT).show()
    }

    private fun openGallery() {
        galleryLauncher.launch("image/*")
    }

    private fun updateHealthStatusFirebase() {
        val healthValue = seekBarHealth.progress
        val tree = selectedTree

        if (tree == null) {
            Toast.makeText(this, "No tree selected", Toast.LENGTH_SHORT).show()
            return
        }

        tree.health = healthValue

        TreeStorage.updateTree(tree) {
            Toast.makeText(this, "✅ Updated health for ${tree.name}", Toast.LENGTH_SHORT).show()
            updateLastCheckDate()
        }
    }
}

